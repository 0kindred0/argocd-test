# AI 原生 SDLC Custom Agents 使用说明

基于 Anthropic《The AI-Native SDLC Playbook》的六个阶段（Plan → Design → Build → Test → Deploy → Maintain）生成的 12 个 custom agent，每个 play 一个，可直接在 VS Code 中使用。

## 文件结构

```
ai-native-sdlc/
├── AI-Native-SDLC-Playbook-中文翻译.md   # 原文完整中文翻译
├── claude-code-agents/                   # Claude Code 用（12 个 .md）
└── copilot-agents/                       # GitHub Copilot 用（12 个 .agent.md）
```

## 安装方式

### Claude Code（VS Code 扩展 / CLI）
把 `claude-code-agents/` 下的 `.md` 文件复制到项目的 `.claude/agents/` 目录：

```bash
mkdir -p .claude/agents
cp claude-code-agents/*.md .claude/agents/
```

提交到 git 后全团队共享。在会话中 Claude 会按 `description` 自动委派，也可以用 `@agent-<name>` 显式调用（如 `@agent-pr-reviewer`）。

### GitHub Copilot（VS Code）
把 `copilot-agents/` 下的 `.agent.md` 文件复制到项目的 `.github/agents/` 目录：

```bash
mkdir -p .github/agents
cp copilot-agents/*.agent.md .github/agents/
```

在 Copilot Chat 的代理下拉菜单中即可选择对应的 custom agent。

## Agent 与 SDLC 阶段对照

| 阶段 | Agent | 作用 |
| --- | --- | --- |
| 01 Plan | intent-capture | 头脑风暴 → 生成 `intent.md` |
| 02 Design | requirements-design | `intent.md` → `spec.md`，标记关注区域 |
| 03 Build | plan-architect | plan mode：产出 `plan.md`，先计划后写码 |
| 03 Build | claude-md-maintainer | 维护 `CLAUDE.md`（两次规则） |
| 03 Build | skill-writer | 把组织策略固化为 Skill |
| 03/04 Build/Test | verifier | 独立验证：运行应用、只报告不修复 |
| 04 Test | feedback-loop-coach | 建立自验证反馈环、失败测试先行 |
| 04 Test | eval-runner | agent 配置的回归 evals（CI 中运行） |
| 05 Deploy | pr-reviewer | 按 REVIEW.md 三环节评审（Bugs/Security/Compliance） |
| 05 Deploy | release-gatekeeper | 发布门禁：分级自治、生产关卡、回滚优先 |
| 06 Maintain | loop-closer | 告警 → 诊断 → `intent.md` 闭环 |
| 06 Maintain | security-scan-triager | 安全扫描发现分流与修复 |

## 推荐落地顺序（按原文依赖图）

1. **可从任意一个开始**：intent-capture、claude-md-maintainer、feedback-loop-coach、release-gatekeeper、plan-architect
2. 第二层：skill-writer、verifier、eval-runner
3. 第三层：requirements-design、pr-reviewer
4. 第四层：CI/CD 集成（release-gatekeeper 的流水线部分）
5. 第五层：loop-closer、security-scan-triager（闭环）

## 工件链

```
intent.md → spec.md → plan.md → diff + tests → PR + 评审结论 → 事故记录 → 新的 intent.md
```

每个阶段提交一个工件，下一个阶段读取它——这条提交链同时就是审计轨迹。
