# <项目名>

## Commands
- Build: make build（必须以 "Build succeeded" 结束）
- Test: make test（单元，全绿）、make itest（集成，需要 docker）
- Lint: make lint（零警告；CI 中运行，推送前修好）

## Conventions
- <语言/框架版本与关键约定，如：金额用 BigDecimal，绝不用 double>
- <测试约定，如：每个端点需要集成测试>

## Architecture
- <目录职责划分>
- <生成代码/冻结目录位置，禁止编辑>

## Things Claude gets wrong
- <反复出现的错误及纠正——同一错误犯两次就写进来>

## Verifying your work
报告任何任务完成前运行 Build / Test / Lint 并粘贴输出。
测试失败时修代码，不是修测试；绝不跳过或删除失败的测试。
