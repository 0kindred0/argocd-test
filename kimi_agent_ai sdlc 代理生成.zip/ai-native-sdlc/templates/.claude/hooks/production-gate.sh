#!/bin/bash
# 生产部署需要具名的发布授权
cmd=$(jq -r '.tool_input.command' < /dev/stdin)
if [[ "$cmd" == *"deploy"* && "$cmd" == *"production"* ]]; then
   if [ -z "$RELEASE_APPROVAL" ]; then
     echo "生产部署需要发布授权（设置 RELEASE_APPROVAL）。" >&2
     exit 2 # exit 2 阻断动作；消息会传给 Claude
   fi
fi
exit 0
