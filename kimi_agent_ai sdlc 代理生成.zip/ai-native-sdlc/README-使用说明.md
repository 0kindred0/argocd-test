# AI 原生 SDLC Agents 使用说明

基于 Anthropic《The AI-Native SDLC Playbook》生成：**每个阶段（step）一个 agent**，共 6 个，每个 agent 覆盖该阶段的全部 plays。另附原文完整中文翻译和一套可直接入库的配套模板。

## 文件结构

```
ai-native-sdlc/
├── AI-Native-SDLC-Playbook-中文翻译.md   # 原文完整中文翻译
├── claude-code-agents/                   # Claude Code 用（6 个 .md）
│   ├── step1-plan.md        规划：捕获意图 → intent.md
│   ├── step2-design.md      设计：intent.md → spec.md
│   ├── step3-build.md       构建：plan mode / CLAUDE.md / skills / hooks / 并行
│   ├── step4-test.md        测试：反馈环 + CI 持续 evals
│   ├── step5-deploy.md      部署：PR 评审 / hooks 审批关卡 / CI/CD
│   └── step6-maintain.md    维护：闭环 / 安全扫描 / 值班响应
├── copilot-agents/                       # Copilot 用（6 个 .agent.md，同名）
└── templates/                            # 配套模板（见下）
```

## 安装

### Claude Code（VS Code 扩展 / CLI）
```bash
mkdir -p .claude/agents
cp claude-code-agents/*.md .claude/agents/
```
提交到 git 全团队共享。会话中按 description 自动委派，或 `@agent-step3-build` 显式调用。

### GitHub Copilot（VS Code）
```bash
mkdir -p .github/agents
cp copilot-agents/*.agent.md .github/agents/
```
在 Copilot Chat 的代理下拉菜单中选择对应阶段的 agent。

## 配套模板（templates/）

| 文件 | 对应阶段 | 用途 |
| --- | --- | --- |
| `CLAUDE.md` | Build | 机构知识模板，放仓库根目录 |
| `REVIEW.md` | Deploy | PR 评审策略，放仓库根目录 |
| `.claude/settings.json` + `.claude/hooks/production-gate.sh` | Deploy | 生产部署审批关卡 hook |
| `bands.yaml` | Maintain | 闭环控制带分级配置（1σ 日志 / 2σ 诊断 / 3σ 行动） |
| `agent-evals.yml` | Test | CI 持续 evals 工作流（放 `.github/workflows/`） |
| `intent.md` / `plan.md` | Plan / Build | 工件模板 |
| `verifier-subagent.md` | Build/Test | 独立验证子智能体（放 `.claude/agents/`） |

## 工件链（审计轨迹）

```
intent.md → spec.md → plan.md → diff + tests → PR + 评审结论 → 事故记录 → 新的 intent.md
```

## 推荐落地顺序（按原文依赖图）

1. **可从任意起步**：step1-plan、step3-build（CLAUDE.md 部分）、step4-test（反馈环）、step5-deploy（hooks 关卡）
2. 然后：skills、子智能体、evals
3. 再然后：step2-design、PR 评审
4. 最后：CI/CD 集成 → step6-maintain 闭环
